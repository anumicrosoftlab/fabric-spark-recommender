# spark_app_analyzer/__init__.py

from .core import get_spark_session, extract_app_metadata
from .metrics import compute_stage_task_summary, compute_application_runtime, compute_executor_wall_clock_time
from .predictor import estimate_runtime_scaling
from .recommendations import generate_recommendations

def analyze(eventlog_df, metadata_df, app_id):
    """
    Wrapper function that returns the 5 key DataFrames for one app_id:
    (app_metadata_df, stage_summary_df, metrics_df, predictions_df, recommendations_df)
    """
    app_metadata_df = extract_app_metadata(eventlog_df)
    stage_summary_df, metrics_df, predictions_df, recommendations_df = compute_stage_task_summary(eventlog_df, metadata_df, app_id)
    # Return all 5 (including app metadata)
    return app_metadata_df, stage_summary_df, metrics_df, predictions_df, recommendations_df